create function st_histogram(rastertable text, rastercolumn text, nband integer, exclude_nodata_value boolean, bins integer, "right" boolean, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) returns SETOF record
    stable
    strict
    language sql
as
$$
SELECT public._ST_histogram($1, $2, $3, $4, 1, $5, NULL, $6)
$$;

comment on function st_histogram(text, text, integer, boolean, integer, boolean, out double precision, out double precision, out bigint, out double precision) is 'args: rastertable, rastercolumn, nband, exclude_nodata_value, bins, right - Returns a set of record summarizing a raster or raster coverage data distribution separate bin ranges. Number of bins are autocomputed if not specified.';

alter function st_histogram(text, text, integer, boolean, integer, boolean, out double precision, out double precision, out bigint, out double precision) owner to postgres;

