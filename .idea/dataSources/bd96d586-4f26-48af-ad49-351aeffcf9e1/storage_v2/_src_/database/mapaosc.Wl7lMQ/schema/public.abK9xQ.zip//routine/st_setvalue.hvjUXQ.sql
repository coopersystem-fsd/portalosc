create function st_setvalue(rast raster, geom geometry, newvalue double precision) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT public.ST_setvalues($1, 1, ARRAY[ROW($2, $3)]::geomval[], FALSE)
$$;

comment on function st_setvalue(raster, geometry, double precision) is 'args: rast, geom, newvalue - Returns modified raster resulting from setting the value of a given band in a given columnx, rowy pixel or the pixels that intersect a particular geometry. Band numbers start at 1 and assumed to be 1 if not specified.';

alter function st_setvalue(raster, geometry, double precision) owner to postgres;

