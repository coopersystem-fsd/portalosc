create function st_summarystats(rastertable text, rastercolumn text, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true) returns summarystats
    stable
    strict
    language sql
as
$$
SELECT public._ST_summarystats($1, $2, $3, $4, 1)
$$;

comment on function st_summarystats(text, text, integer, boolean) is 'args: rastertable, rastercolumn, nband=1, exclude_nodata_value=true - Returns summarystats consisting of count, sum, mean, stddev, min, max for a given raster band of a raster or raster coverage. Band 1 is assumed is no band is specified.';

alter function st_summarystats(text, text, integer, boolean) owner to postgres;

