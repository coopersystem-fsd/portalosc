create function st_transform(geom geometry, from_proj text, to_srid integer) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT postgis_transform_geometry($1, $2, proj4text, $3)
FROM spatial_ref_sys WHERE srid=$3;
$$;

comment on function st_transform(geometry, text, integer) is 'args: geom, from_proj, to_srid - Return a new geometry with its coordinates transformed to a different spatial reference.';

alter function st_transform(geometry, text, integer) owner to postgres;

